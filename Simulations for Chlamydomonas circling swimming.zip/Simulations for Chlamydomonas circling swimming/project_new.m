function [phase,Max_Alpha,Min_Alpha,Ave_Alpha,dia,pitch]=project_new(k1,k2,nc,adr0n, ar0n, aden)

n = mean(adr0n(:,k1:k2),2);  
p = [0,0,0]; 

[x0,y0] = size(adr0n);

phase = zeros(2,y0);
dia = zeros(1,y0);

m = mean(ar0n(:,k1:k2),2);  

A = n(1);
B = n(2);
C = n(3);
D = -n(1)*p(1)-n(2)*p(2)-n(3)*p(3);

for i = k1:k2

   t_b = (A*ar0n(1,i) + B*ar0n(2,i) + C*ar0n(3,i) + D) / (A^2 + B^2 + C^2);
   t_c = (A*m(1) + B*m(2) + C*m(3) + D) / (A^2 + B^2 + C^2);
   t_e = (A*(ar0n(1,i)-0.1*aden(1,i)) + B*(ar0n(2,i)-0.1*aden(2,i)) + C*(ar0n(3,i)-0.1*aden(3,i)) + D) / (A^2 + B^2 + C^2);

   b_p = [ar0n(1,i)-A*t_b ; ar0n(2,i)-B*t_b ; ar0n(3,i)-C*t_b];
   c_p = [m(1)-A*t_c ; m(2)-B*t_c ; m(3)-C*t_c];
   e_p = [(ar0n(1,i)-0.1*aden(1,i))-A*t_e ; (ar0n(2,i)-0.1*aden(2,i))-B*t_e ; (ar0n(3,i)-0.1*aden(3,i))-C*t_e];

   v1 = c_p - b_p;
   v2 = e_p - b_p;

   phase(1,i) = acos(dot(v1,v2)/(norm(v1)*norm(v2)));

   phase(2,i) = dot(cross(v1,v2),n); 

   if phase(2,i)<0
       phase(1,i)=2*pi-phase(1,i);
   end

   phase(1,i) = phase(1,i)/pi*180; 


   dia(1,i) = 2 * sqrt((b_p(1)-c_p(1))^2 + (b_p(2)-c_p(2))^2 + (b_p(3)-c_p(3))^2);

end

Max_Alpha = max(phase(1,k1:k2)) - 90;
Min_Alpha = min(phase(1,k1:k2)) - 90;
Ave_Alpha = mean(phase(1,k1:k2)) - 90;

phase(3,:)=phase(1,:)-90;

pitch = sqrt((ar0n(1,k1)-ar0n(1,k2))^2 + (ar0n(2,k1)-ar0n(2,k2))^2 + (ar0n(3,k1)-ar0n(3,k2))^2) / nc;

end