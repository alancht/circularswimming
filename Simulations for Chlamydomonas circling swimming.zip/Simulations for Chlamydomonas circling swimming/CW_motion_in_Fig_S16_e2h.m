close all;
clc;
clear;
Fw = [0.4468	0.5683	0.2722	0.1559	0.4168	0.5712	0.2566	0.1437];  % mean
R = 0;

%% define simulation parameter
ti = 0;
tf = 3300;
dt = 0.05;   
tn=dt:dt:tf;
nt=length(tn);

%% model input parameters
a0=0.5;    
a1=0.075;    
a2=0.075;     
mu=(10.6/10)^2;

phi1=0*pi;            
phi2=0*pi;             
beta1=0.3;             
beta2=0.3; 

b1 = 0.8;
b2 = 1.5;

c10=0.7;      
c20=0.7;
c1=c10;
c2=c20;

theta1=180/180*pi;
theta2=210/180*pi;

f10 = 0;
f20 = 0;
f1=f10;
f2=f20;

l10=Fw(5)*b1;        
l20=Fw(1)*b1;       
h10=Fw(6)*b1;
h20=Fw(2)*b1;
l1=l10;
l2=l20;
h1=h10;
h2=h20;

Ra10=Fw(8)*b2;
Rb10=Fw(7)*b2;  
Ra20=Fw(4)*b2;
Rb20=Fw(3)*b2;
Ra1=Ra10;
Rb1=Rb10;
Ra2=Ra20;
Rb2=Rb20;

Ix=1;
Iy=0;
Iz=0;

I0=1;
p1=-0.05;      
p2=+0.05;      

r0_l=[0;0;0];     

theta=[0;  1*pi/2];
dr0_l=[cos(theta(1))*cos(theta(2));   sin(theta(1))*cos(theta(2));   sin(theta(2))];    

deye_l=[sin(pi/4);  -sin(pi/4);  0];    
dyaw_l=deye_l;   

dp_l =[-sin(pi/4);  -sin(pi/4);  0];    

ex_b=[1;0;0];       
ey_b=[0;1;0];
ez_b=[0;0;1];

ex_l=[1;0;0];         
ey_l=[0;1;0];
ez_l=[0;0;1];

a_orbit1=pi/2-beta1;
v_orbit1     =  quater(ez_b,ex_b,a_orbit1);    

a_orbit2=beta2;
v_orbit2     =  quater(ey_b,ex_b,a_orbit2); 

vn1_0= ex_b;
vn2_0=-ex_b;

%%  
vn1_0        =  quater(vn1_0,ez_b,f1);
vn2_0        =  quater(vn2_0,ez_b,f2);
v_orbit1     =  quater(v_orbit1,ez_b,f1);
v_orbit2     =  quater(v_orbit2,ez_b,f2);

%%
F1n_l     =  quater(vn1_0,v_orbit1,phi1); 
F2n_l     =  quater(vn2_0,v_orbit2,phi2); 
F1t_l     =  quater(F1n_l,v_orbit1,pi/2); 
F2t_l     =  quater(F2n_l,v_orbit2,pi/2);

r01=[-l1;0;h1];
r02=[l2;0;h2];
r01  =  quater(r01,ez_b,f1);
r02  =  quater(r02,ez_b,f2);

phi11=atan2(sin(phi1)*Ra1,cos(phi1)*Rb1);
phi22=atan2(sin(phi2)*Ra2,cos(phi2)*Rb2);
R1=sqrt(Ra1*Ra1*cos(phi11)*cos(phi11) + Rb1*Rb1*sin(phi11)*sin(phi11));
R2=sqrt(Ra2*Ra2*cos(phi22)*cos(phi22) + Rb2*Rb2*sin(phi22)*sin(phi22));

r1_l=r0_l+r01+R1*F1n_l;        
r2_l=r0_l+r02+R2*F2n_l;

r1_lp=r0_l+r01/b1+R1/b2*F1n_l;       
r2_lp=r0_l+r02/b1+R2/b2*F2n_l;

F1t=1+c1*cos(phi1+theta1);
F2t=1+c2*cos(phi2+theta2);

%% dr/dtheta
R1n=zeros(1,360);
R2n=zeros(1,360);
R1ns=zeros(1,360);
R2ns=zeros(1,360);
for i = 0:pi/180:2*pi
    phi11=atan2(sin(i)*Ra1,cos(i)*Rb1);
    phi22=atan2(sin(i)*Ra2,cos(i)*Rb2);
    i1=round(i/(pi/180)+1);
    R1n(1,i1)=sqrt(Ra1*Ra1*cos(phi11)*cos(phi11) + Rb1*Rb1*sin(phi11)*sin(phi11));
    R2n(1,i1)=sqrt(Ra2*Ra2*cos(phi22)*cos(phi22) + Rb2*Rb2*sin(phi22)*sin(phi22));
end
for i = 1:360
    R1ns(1,i)=(R1n(1,i+1)-R1n(1,i))*180/pi;
    R2ns(1,i)=(R2n(1,i+1)-R2n(1,i))*180/pi;
end

%% define data matrix
aphi1n=zeros(1,nt);
aphi2n=zeros(1,nt);
adphi1n=zeros(1,nt);
adphi2n=zeros(1,nt);
awn=zeros(3,nt);
ar0n=zeros(3,nt);
ar1n=zeros(3,nt);
ar2n=zeros(3,nt);
adr0n=zeros(3,nt);
aden=zeros(3,nt);
adyn=zeros(3,nt);
adpn=zeros(3,nt);
aorbit1=zeros(3,nt);
aorbit2=zeros(3,nt);
avn1_0=zeros(3,nt);
avn2_0=zeros(3,nt);
ar01=zeros(3,nt);
ar02=zeros(3,nt);
aF1n_l=zeros(3,nt);
aF1t_l=zeros(3,nt);
aF2n_l=zeros(3,nt);
aF2t_l=zeros(3,nt);
aI1=zeros(1,nt);
apI1=zeros(1,nt);
ac1=zeros(1,nt);
ac2=zeros(1,nt);

ah1=zeros(1,nt);
ah2=zeros(1,nt);

aR1=zeros(1,nt);
aR2=zeros(1,nt);

abwn=zeros(3,nt);
abT1n=zeros(3,nt);
abT2n=zeros(3,nt);

aF1n=zeros(1,nt);
aF2n=zeros(1,nt);
aF1t=zeros(1,nt);
aF2t=zeros(1,nt);

ar1np=zeros(3,nt);
ar2np=zeros(3,nt);

aXI1=zeros(1,nt);

af1=zeros(1,nt);
af2=zeros(1,nt);

aT1n=zeros(3,nt);
aT2n=zeros(3,nt);

%% Iteration
for i=1:nt

    [X]=Oseen_tensor(r0_l,r1_l,r2_l,phi1,phi2,theta1,theta2,F1n_l,F1t_l,F2n_l,F2t_l,v_orbit1,v_orbit2,mu,Ra1,Rb1,Ra2,Rb2,R1ns,R2ns,a1,a2,a0,c1,c2);

    F1n=X(1);
    F2n=X(2);
    wx=X(3);
    wy=X(4);
    wz=X(5);
    dphi1=X(6);
    dphi2=X(7);
    F0x=X(8);
    F0y=X(9);
    F0z=X(10);
    v1n=X(11);
    v1t=X(12);
    v2n=X(13);
    v2t=X(14);
    v0x=X(15);
    v0y=X(16);
    v0z=X(17);
    F1p=X(18);
    F2p=X(19);
    v1p=X(20);
    v2p=X(21);
    F1t=1+c1*cos(phi1+theta1);
    F2t=1+c2*cos(phi2+theta2);

%% calculate torque
   w=[wx; wy; wz];
   r10=r1_l-r0_l;
   r20=r2_l-r0_l;
   F0=[F0x; F0y; F0z];
   F1=F1n*F1n_l + F1t*F1t_l + F1p*v_orbit1;
   F2=F2n*F2n_l + F2t*F2t_l + F2p*v_orbit2;

   vleft7 = 8*pi*mu*a0*a0*a0*w + cross(r10,F1) + cross(r20,F2);

    T1 = cross(r10,F1);
    T2 = cross(r20,F2);


    Ldr = dr0_l;
    Ldy = dyaw_l;
    Ldp = dp_l;
    L_M = [Ldr(1), Ldy(1), Ldp(1);  Ldr(2), Ldy(2), Ldp(2);  Ldr(3), Ldy(3), Ldp(3)];

    Bw = L_M \ w;
    BT1 = L_M \ T1;
    BT2 = L_M \ T2;

    abwn(:,i)=Bw;
    abT1n(:,i)=BT1;
    abT2n(:,i)=BT2;

    aT1n(:,i)=T1;
    aT2n(:,i)=T2;


%% resonding to light

    I1=-(Ix*deye_l(1)+Iy*deye_l(2)+Iz*deye_l(3));    % evec: direction of maximal light sensitivity
    
    xI1 = acos(I1);

    if (Ix==0 && Iy==0 && Iz==0)
            p=0;      
    end

    I1=1+I0*I1*heaviside(I1);

Lt = 4530;
    if I1 > 1.05 && R == 0
        f1 =  0.3*sin(R/Lt*pi);
        R = R + 1;
    elseif R>0 && R<(4*Lt/4)
        f1 =  0.3*sin(R/Lt*pi);
        R = R + 1;
    elseif R==4*Lt/4
        f1 = 0;
        f2 = 0;
        R = 0;
    end


%% Update position
    aphi1n(:,i)=phi1;
    aphi2n(:,i)=phi2;
    adphi1n(:,i)=dphi1;
    adphi2n(:,i)=dphi2;
    awn(:,i)=[X(3);X(4);X(5)];
    ar0n(:,i)=r0_l;     
    ar1n(:,i)=r1_l;
    ar2n(:,i)=r2_l;
    adr0n(:,i)=dr0_l;
    aden(:,i)=deye_l;
    adyn(:,i)=dyaw_l;
    adpn(:,i)=dp_l;
    aorbit1(:,i)=v_orbit1;
    aorbit2(:,i)=v_orbit2;
    avn1_0(:,i)=vn1_0;
    avn2_0(:,i)=vn2_0;
    ar01(:,i)=r01;
    ar02(:,i)=r02;
    aF1n_l(:,i)=F1n_l;
    aF1t_l(:,i)=F1t_l;
    aF2n_l(:,i)=F2n_l;
    aF2t_l(:,i)=F2t_l;
    aI1(:,i)=I1;
    apI1(:,i)=log(I1);
    ac1(:,i)=c1;
    ac2(:,i)=c2;

    ah1(:,i)=h1;
    ah2(:,i)=h2;

    aR1(:,i)=(Ra1+Rb1)/2;
    aR2(:,i)=(Ra2+Rb2)/2;

    aF1n(:,i)=F1n;
    aF2n(:,i)=F2n;    
    aF1t(:,i)=F1t;
    aF2t(:,i)=F2t; 

    ar1np(:,i)=r1_lp;
    ar2np(:,i)=r2_lp;

    aXI1(:,i)=xI1;

    af1(:,i)=f1;
    af2(:,i)=f2;
%% RK4
% k1
    v0x_k1 = X(15);
    v0y_k1 = X(16);
    v0z_k1 = X(17);
    v1x_k1 = X(11)*F1n_l(1) + X(12)*F1t_l(1) + X(20)*v_orbit1(1);
    v1y_k1 = X(11)*F1n_l(2) + X(12)*F1t_l(2) + X(20)*v_orbit1(2);
    v1z_k1 = X(11)*F1n_l(3) + X(12)*F1t_l(3) + X(20)*v_orbit1(3);
    v2x_k1 = X(13)*F2n_l(1) + X(14)*F2t_l(1) + X(21)*v_orbit2(1);
    v2y_k1 = X(13)*F2n_l(2) + X(14)*F2t_l(2) + X(21)*v_orbit2(2);
    v2z_k1 = X(13)*F2n_l(3) + X(14)*F2t_l(3) + X(21)*v_orbit2(3);

    dphi1_k1 = X(6);
    dphi2_k1 = X(7);
    w0x_k1 = X(3);
    w0y_k1 = X(4);
    w0z_k1 = X(5);

 % k2
    r0_l_k2 = r0_l;
    r1_l_k2 = r1_l;
    r2_l_k2 = r2_l;
    phi1_k2 = phi1;
    phi2_k2 = phi2;
    v_orbit1_k2 = v_orbit1;
    v_orbit2_k2 = v_orbit2;
    vn1_0_k2 = vn1_0;
    vn2_0_k2 = vn2_0;


    r0_l_k2(1)=r0_l_k2(1)+dt/2*v0x_k1;
    r0_l_k2(2)=r0_l_k2(2)+dt/2*v0y_k1;
    r0_l_k2(3)=r0_l_k2(3)+dt/2*v0z_k1;

    r1_l_k2(1)=r1_l_k2(1)+dt/2*v1x_k1;
    r1_l_k2(2)=r1_l_k2(2)+dt/2*v1y_k1;
    r1_l_k2(3)=r1_l_k2(3)+dt/2*v1z_k1;

    r2_l_k2(1)=r2_l_k2(1)+dt/2*v2x_k1;
    r2_l_k2(2)=r2_l_k2(2)+dt/2*v2y_k1;
    r2_l_k2(3)=r2_l_k2(3)+dt/2*v2z_k1;

    phi1_k2=phi1_k2+dt/2*dphi1_k1;
    phi2_k2=phi2_k2+dt/2*dphi2_k1;

    v_orbit1_k2     =  quater(v_orbit1_k2,ex_l,w0x_k1*dt/2); 
    v_orbit2_k2     =  quater(v_orbit2_k2,ex_l,w0x_k1*dt/2); 
    vn1_0_k2        =  quater(vn1_0_k2,ex_l,w0x_k1*dt/2);
    vn2_0_k2        =  quater(vn2_0_k2,ex_l,w0x_k1*dt/2);

    v_orbit1_k2     =  quater(v_orbit1_k2,ey_l,w0y_k1*dt/2); 
    v_orbit2_k2     =  quater(v_orbit2_k2,ey_l,w0y_k1*dt/2); 
    vn1_0_k2        =  quater(vn1_0_k2,ey_l,w0y_k1*dt/2);
    vn2_0_k2        =  quater(vn2_0_k2,ey_l,w0y_k1*dt/2);

    v_orbit1_k2     =  quater(v_orbit1_k2,ez_l,w0z_k1*dt/2); 
    v_orbit2_k2     =  quater(v_orbit2_k2,ez_l,w0z_k1*dt/2); 
    vn1_0_k2        =  quater(vn1_0_k2,ez_l,w0z_k1*dt/2);
    vn2_0_k2        =  quater(vn2_0_k2,ez_l,w0z_k1*dt/2);

    F1n_l_k2        =  quater(vn1_0_k2,v_orbit1_k2,phi1_k2);
    F2n_l_k2        =  quater(vn2_0_k2,v_orbit2_k2,phi2_k2);
    F1t_l_k2        =  quater(F1n_l_k2,v_orbit1_k2,pi/2);
    F2t_l_k2        =  quater(F2n_l_k2,v_orbit2_k2,pi/2);

    [X_k2]=Oseen_tensor(r0_l_k2,r1_l_k2,r2_l_k2,phi1_k2,phi2_k2,theta1,theta2,F1n_l_k2,F1t_l_k2,F2n_l_k2,F2t_l_k2,v_orbit1_k2,v_orbit2_k2,mu,Ra1,Rb1,Ra2,Rb2,R1ns,R2ns,a1,a2,a0,c1,c2);

    v0x_k2 = X_k2(15);
    v0y_k2 = X_k2(16);
    v0z_k2 = X_k2(17);
    v1x_k2 = X_k2(11)*F1n_l_k2(1) + X_k2(12)*F1t_l_k2(1) + X_k2(20)*v_orbit1_k2(1);
    v1y_k2 = X_k2(11)*F1n_l_k2(2) + X_k2(12)*F1t_l_k2(2) + X_k2(20)*v_orbit1_k2(2);
    v1z_k2 = X_k2(11)*F1n_l_k2(3) + X_k2(12)*F1t_l_k2(3) + X_k2(20)*v_orbit1_k2(3);
    v2x_k2 = X_k2(13)*F2n_l_k2(1) + X_k2(14)*F2t_l_k2(1) + X_k2(21)*v_orbit2_k2(1);
    v2y_k2 = X_k2(13)*F2n_l_k2(2) + X_k2(14)*F2t_l_k2(2) + X_k2(21)*v_orbit2_k2(2);
    v2z_k2 = X_k2(13)*F2n_l_k2(3) + X_k2(14)*F2t_l_k2(3) + X_k2(21)*v_orbit2_k2(3);

    dphi1_k2 = X_k2(6);
    dphi2_k2 = X_k2(7);
    w0x_k2 = X_k2(3);
    w0y_k2 = X_k2(4);
    w0z_k2 = X_k2(5);
 
 % k3
    r0_l_k3 = r0_l;
    r1_l_k3 = r1_l;
    r2_l_k3 = r2_l;
    phi1_k3 = phi1;
    phi2_k3 = phi2;
    v_orbit1_k3 = v_orbit1;
    v_orbit2_k3 = v_orbit2;
    vn1_0_k3 = vn1_0;
    vn2_0_k3 = vn2_0;


    r0_l_k3(1)=r0_l_k3(1)+dt/2*v0x_k2;
    r0_l_k3(2)=r0_l_k3(2)+dt/2*v0y_k2;
    r0_l_k3(3)=r0_l_k3(3)+dt/2*v0z_k2;

    r1_l_k3(1)=r1_l_k3(1)+dt/2*v1x_k2;
    r1_l_k3(2)=r1_l_k3(2)+dt/2*v1y_k2;
    r1_l_k3(3)=r1_l_k3(3)+dt/2*v1z_k2;

    r2_l_k3(1)=r2_l_k3(1)+dt/2*v2x_k2;
    r2_l_k3(2)=r2_l_k3(2)+dt/2*v2y_k2;
    r2_l_k3(3)=r2_l_k3(3)+dt/2*v2z_k2;

    phi1_k3=phi1_k3+dt/2*dphi1_k2;
    phi2_k3=phi2_k3+dt/2*dphi2_k2;

    v_orbit1_k3     =  quater(v_orbit1_k3,ex_l,w0x_k2*dt/2); 
    v_orbit2_k3     =  quater(v_orbit2_k3,ex_l,w0x_k2*dt/2); 
    vn1_0_k3        =  quater(vn1_0_k3,ex_l,w0x_k2*dt/2);
    vn2_0_k3        =  quater(vn2_0_k3,ex_l,w0x_k2*dt/2);

    v_orbit1_k3     =  quater(v_orbit1_k3,ey_l,w0y_k2*dt/2); 
    v_orbit2_k3     =  quater(v_orbit2_k3,ey_l,w0y_k2*dt/2); 
    vn1_0_k3        =  quater(vn1_0_k3,ey_l,w0y_k2*dt/2);
    vn2_0_k3        =  quater(vn2_0_k3,ey_l,w0y_k2*dt/2);

    v_orbit1_k3     =  quater(v_orbit1_k3,ez_l,w0z_k2*dt/2); 
    v_orbit2_k3     =  quater(v_orbit2_k3,ez_l,w0z_k2*dt/2); 
    vn1_0_k3        =  quater(vn1_0_k3,ez_l,w0z_k2*dt/2);
    vn2_0_k3        =  quater(vn2_0_k3,ez_l,w0z_k2*dt/2);

    F1n_l_k3        =  quater(vn1_0_k3,v_orbit1_k3,phi1_k3);
    F2n_l_k3        =  quater(vn2_0_k3,v_orbit2_k3,phi2_k3);
    F1t_l_k3        =  quater(F1n_l_k3,v_orbit1_k3,pi/2);
    F2t_l_k3        =  quater(F2n_l_k3,v_orbit2_k3,pi/2);

    [X_k3]=Oseen_tensor(r0_l_k3,r1_l_k3,r2_l_k3,phi1_k3,phi2_k3,theta1,theta2,F1n_l_k3,F1t_l_k3,F2n_l_k3,F2t_l_k3,v_orbit1_k3,v_orbit2_k3,mu,Ra1,Rb1,Ra2,Rb2,R1ns,R2ns,a1,a2,a0,c1,c2);

    v0x_k3 = X_k3(15);
    v0y_k3 = X_k3(16);
    v0z_k3 = X_k3(17);
    v1x_k3 = X_k3(11)*F1n_l_k3(1) + X_k3(12)*F1t_l_k3(1) + X_k3(20)*v_orbit1_k3(1);
    v1y_k3 = X_k3(11)*F1n_l_k3(2) + X_k3(12)*F1t_l_k3(2) + X_k3(20)*v_orbit1_k3(2);
    v1z_k3 = X_k3(11)*F1n_l_k3(3) + X_k3(12)*F1t_l_k3(3) + X_k3(20)*v_orbit1_k3(3);
    v2x_k3 = X_k3(13)*F2n_l_k3(1) + X_k3(14)*F2t_l_k3(1) + X_k3(21)*v_orbit2_k3(1);
    v2y_k3 = X_k3(13)*F2n_l_k3(2) + X_k3(14)*F2t_l_k3(2) + X_k3(21)*v_orbit2_k3(2);
    v2z_k3 = X_k3(13)*F2n_l_k3(3) + X_k3(14)*F2t_l_k3(3) + X_k3(21)*v_orbit2_k3(3);

    dphi1_k3 = X_k3(6);
    dphi2_k3 = X_k3(7);
    w0x_k3 = X_k3(3);
    w0y_k3 = X_k3(4);
    w0z_k3 = X_k3(5);

 % k4
    r0_l_k4 = r0_l;
    r1_l_k4 = r1_l;
    r2_l_k4 = r2_l;
    phi1_k4 = phi1;
    phi2_k4 = phi2;
    v_orbit1_k4 = v_orbit1;
    v_orbit2_k4 = v_orbit2;
    vn1_0_k4 = vn1_0;
    vn2_0_k4 = vn2_0;


    r0_l_k4(1)=r0_l_k4(1)+dt*v0x_k3;
    r0_l_k4(2)=r0_l_k4(2)+dt*v0y_k3;
    r0_l_k4(3)=r0_l_k4(3)+dt*v0z_k3;

    r1_l_k4(1)=r1_l_k4(1)+dt*v1x_k3;
    r1_l_k4(2)=r1_l_k4(2)+dt*v1y_k3;
    r1_l_k4(3)=r1_l_k4(3)+dt*v1z_k3;

    r2_l_k4(1)=r2_l_k4(1)+dt*v2x_k3;
    r2_l_k4(2)=r2_l_k4(2)+dt*v2y_k3;
    r2_l_k4(3)=r2_l_k4(3)+dt*v2z_k3;

    phi1_k4=phi1_k4+dt*dphi1_k3;
    phi2_k4=phi2_k4+dt*dphi2_k3;

    v_orbit1_k4     =  quater(v_orbit1_k4,ex_l,w0x_k3*dt); 
    v_orbit2_k4     =  quater(v_orbit2_k4,ex_l,w0x_k3*dt); 
    vn1_0_k4        =  quater(vn1_0_k4,ex_l,w0x_k3*dt);
    vn2_0_k4        =  quater(vn2_0_k4,ex_l,w0x_k3*dt);

    v_orbit1_k4     =  quater(v_orbit1_k4,ey_l,w0y_k3*dt); 
    v_orbit2_k4     =  quater(v_orbit2_k4,ey_l,w0y_k3*dt); 
    vn1_0_k4        =  quater(vn1_0_k4,ey_l,w0y_k3*dt);
    vn2_0_k4        =  quater(vn2_0_k4,ey_l,w0y_k3*dt);

    v_orbit1_k4     =  quater(v_orbit1_k4,ez_l,w0z_k3*dt); 
    v_orbit2_k4     =  quater(v_orbit2_k4,ez_l,w0z_k3*dt); 
    vn1_0_k4        =  quater(vn1_0_k4,ez_l,w0z_k3*dt);
    vn2_0_k4        =  quater(vn2_0_k4,ez_l,w0z_k3*dt);

    F1n_l_k4        =  quater(vn1_0_k4,v_orbit1_k4,phi1_k4);
    F2n_l_k4        =  quater(vn2_0_k4,v_orbit2_k4,phi2_k4);
    F1t_l_k4        =  quater(F1n_l_k4,v_orbit1_k4,pi/2);
    F2t_l_k4        =  quater(F2n_l_k4,v_orbit2_k4,pi/2);

    [X_k4]=Oseen_tensor(r0_l_k4,r1_l_k4,r2_l_k4,phi1_k4,phi2_k4,theta1,theta2,F1n_l_k4,F1t_l_k4,F2n_l_k4,F2t_l_k4,v_orbit1_k4,v_orbit2_k4,mu,Ra1,Rb1,Ra2,Rb2,R1ns,R2ns,a1,a2,a0,c1,c2);

    v0x_k4 = X_k4(15);
    v0y_k4 = X_k4(16);
    v0z_k4 = X_k4(17);
    v1x_k4 = X_k4(11)*F1n_l_k4(1) + X_k4(12)*F1t_l_k4(1) + X_k4(20)*v_orbit1_k4(1);
    v1y_k4 = X_k4(11)*F1n_l_k4(2) + X_k4(12)*F1t_l_k4(2) + X_k4(20)*v_orbit1_k4(2);
    v1z_k4 = X_k4(11)*F1n_l_k4(3) + X_k4(12)*F1t_l_k4(3) + X_k4(20)*v_orbit1_k4(3);
    v2x_k4 = X_k4(13)*F2n_l_k4(1) + X_k4(14)*F2t_l_k4(1) + X_k4(21)*v_orbit2_k4(1);
    v2y_k4 = X_k4(13)*F2n_l_k4(2) + X_k4(14)*F2t_l_k4(2) + X_k4(21)*v_orbit2_k4(2);
    v2z_k4 = X_k4(13)*F2n_l_k4(3) + X_k4(14)*F2t_l_k4(3) + X_k4(21)*v_orbit2_k4(3);

    dphi1_k4 = X_k4(6);
    dphi2_k4 = X_k4(7);
    w0x_k4 = X_k4(3);
    w0y_k4 = X_k4(4);
    w0z_k4 = X_k4(5);

    v0x_k = (v0x_k1 + 2*v0x_k2 + 2*v0x_k3 + v0x_k4)/6;
    v0y_k = (v0y_k1 + 2*v0y_k2 + 2*v0y_k3 + v0y_k4)/6;
    v0z_k = (v0z_k1 + 2*v0z_k2 + 2*v0z_k3 + v0z_k4)/6;
    v1x_k = (v1x_k1 + 2*v1x_k2 + 2*v1x_k3 + v1x_k4)/6;
    v1y_k = (v1y_k1 + 2*v1y_k2 + 2*v1y_k3 + v1y_k4)/6;
    v1z_k = (v1z_k1 + 2*v1z_k2 + 2*v1z_k3 + v1z_k4)/6;
    v2x_k = (v2x_k1 + 2*v2x_k2 + 2*v2x_k3 + v2x_k4)/6;
    v2y_k = (v2y_k1 + 2*v2y_k2 + 2*v2y_k3 + v2y_k4)/6;
    v2z_k = (v2z_k1 + 2*v2z_k2 + 2*v2z_k3 + v2z_k4)/6;
    dphi1_k = (dphi1_k1 + 2*dphi1_k2 + 2*dphi1_k3 + dphi1_k4)/6;
    dphi2_k = (dphi2_k1 + 2*dphi2_k2 + 2*dphi2_k3 + dphi2_k4)/6;
    w0x_k = (w0x_k1 + 2*w0x_k2 + 2*w0x_k3 + w0x_k4)/6;
    w0y_k = (w0y_k1 + 2*w0y_k2 + 2*w0y_k3 + w0y_k4)/6;
    w0z_k = (w0z_k1 + 2*w0z_k2 + 2*w0z_k3 + w0z_k4)/6;


    Lw =  [w0x_k; w0y_k; w0z_k];
    Ldr = dr0_l;
    Ldy = dyaw_l;
    Ldp = dp_l;

    L_M = [Ldr(1), Ldy(1), Ldp(1);  Ldr(2), Ldy(2), Ldp(2);  Ldr(3), Ldy(3), Ldp(3)];
    Bw = L_M \ Lw;

    w0x_k=Bw(1);
    w0y_k=Bw(2);
    w0z_k=Bw(3);

    r0_l(1)=r0_l(1)+dt*v0x_k;
    r0_l(2)=r0_l(2)+dt*v0y_k;
    r0_l(3)=r0_l(3)+dt*v0z_k;

    phi1=phi1+dt*dphi1_k;
    phi2=phi2+dt*dphi2_k;

    w0x_k = +w0x_k;
    w0y_k = +w0y_k;
    w0z_k = +w0z_k;

    dr0_l            =  quater(dr0_l,dr0_l,w0x_k*dt);
    deye_l           =  quater(deye_l,dr0_l,w0x_k*dt);
    dyaw_l           =  quater(dyaw_l,dr0_l,w0x_k*dt);
    dp_l             =  quater(dp_l,dr0_l,w0x_k*dt);
    ex_b             =  quater(ex_b,dr0_l,w0x_k*dt);
    ey_b             =  quater(ey_b,dr0_l,w0x_k*dt);
    ez_b             =  quater(ez_b,dr0_l,w0x_k*dt);

    dr0_l            =  quater(dr0_l,dyaw_l,w0y_k*dt);
    deye_l           =  quater(deye_l,dyaw_l,w0y_k*dt);
    dyaw_l           =  quater(dyaw_l,dyaw_l,w0y_k*dt);
    dp_l             =  quater(dp_l,dyaw_l,w0y_k*dt);
    ex_b             =  quater(ex_b,dyaw_l,w0y_k*dt);
    ey_b             =  quater(ey_b,dyaw_l,w0y_k*dt);
    ez_b             =  quater(ez_b,dyaw_l,w0y_k*dt);

    dr0_l            =  quater(dr0_l,dp_l,w0z_k*dt);
    deye_l           =  quater(deye_l,dp_l,w0z_k*dt);
    dyaw_l           =  quater(dyaw_l,dp_l,w0z_k*dt);
    dp_l             =  quater(dp_l,dp_l,w0z_k*dt);
    ex_b             =  quater(ex_b,dp_l,w0z_k*dt);
    ey_b             =  quater(ey_b,dp_l,w0z_k*dt);
    ez_b             =  quater(ez_b,dp_l,w0z_k*dt);

%%
a_orbit1=pi/2-beta1;
v_orbit1     =  quater(ez_b,ex_b,a_orbit1);   

a_orbit2=beta2;
v_orbit2     =  quater(ey_b,ex_b,a_orbit2);

vn1_0= ex_b;
vn2_0=-ex_b;

vn1_0        =  quater(vn1_0,ez_b,f1);
vn2_0        =  quater(vn2_0,ez_b,f2);
v_orbit1     =  quater(v_orbit1,ez_b,f1);
v_orbit2     =  quater(v_orbit2,ez_b,f2);

F1n_l            =  quater(vn1_0,v_orbit1,phi1);
F2n_l            =  quater(vn2_0,v_orbit2,phi2);
F1t_l            =  quater(F1n_l,v_orbit1,pi/2);
F2t_l            =  quater(F2n_l,v_orbit2,pi/2);

phi11=atan2(sin(phi1)*Ra1,cos(phi1)*Rb1);
phi22=atan2(sin(phi2)*Ra2,cos(phi2)*Rb2);
R1=sqrt(Ra1*Ra1*cos(phi11)*cos(phi11) + Rb1*Rb1*sin(phi11)*sin(phi11));
R2=sqrt(Ra2*Ra2*cos(phi22)*cos(phi22) + Rb2*Rb2*sin(phi22)*sin(phi22));

r01=-l1*ex_b + h1*ez_b;
r02= l2*ex_b + h2*ez_b;
r01  =  quater(r01,ez_b,f1);
r02  =  quater(r02,ez_b,f2);

r1_l=r0_l+r01+R1*F1n_l;
r2_l=r0_l+r02+R2*F2n_l;

r1_lp=r0_l+r01/b1+R1/b2*F1n_l;
r2_lp=r0_l+r02/b1+R2/b2*F2n_l;

end

%% Plot trajectory
xn=ar0n;
en=aden;
pn=adr0n;

%for k=1:50:nt
k=nt;
fig1 = figure(1);
set(gcf,'color','white');
clf;
hold on;
grid on;
box on;
bodylength=1;
thickness=1;
frameno=k;

xc=xn(1,frameno);
yc=xn(2,frameno);
zc=xn(3,frameno);

CCN = ceil(nt/1000);
cc36=jet(CCN);
for i = 1:1000:(nt-1000)
     plot3(xn(1,i:100:i+1000),xn(2,i:100:i+1000),xn(3,i:100:i+1000),'color',cc36(ceil(0.001*i),:),'LineWidth',2)
     hold on;
end
     plot3(xn(1,i:100:nt),xn(2,i:100:nt),xn(3,i:100:nt),'color',cc36(CCN,:),'LineWidth',2)
     hold on;

lorbit=zeros(3,105);
rorbit=zeros(3,105);

for j=0:0.02*pi:2.1*pi

    m=round(j/pi/0.02)+1;

    q_lc=[cos(j/2); sin(j/2)*aorbit1(1,k); sin(j/2)*aorbit1(2,k); sin(j/2)*aorbit1(3,k)];
    Q_lc=[1-2*q_lc(3)^2-2*q_lc(4)^2, 2*(q_lc(2)*q_lc(3)-q_lc(1)*q_lc(4)), 2*(q_lc(2)*q_lc(4)+q_lc(1)*q_lc(3));...
             2*(q_lc(2)*q_lc(3)+q_lc(1)*q_lc(4)), 1-2*q_lc(2)^2-2*q_lc(4)^2, 2*(q_lc(3)*q_lc(4)-q_lc(1)*q_lc(2));...
             2*(q_lc(2)*q_lc(4)-q_lc(1)*q_lc(3)), 2*(q_lc(3)*q_lc(4)+q_lc(1)*q_lc(2)), 1-2*q_lc(2)^2-2*q_lc(3)^2];
    nlorbit=Q_lc*avn1_0(:,k);              

    q_rc=[cos(j/2); sin(j/2)*aorbit2(1,k); sin(j/2)*aorbit2(2,k); sin(j/2)*aorbit2(3,k)];
    Q_rc=[1-2*q_rc(3)^2-2*q_rc(4)^2, 2*(q_rc(2)*q_rc(3)-q_rc(1)*q_rc(4)), 2*(q_rc(2)*q_rc(4)+q_rc(1)*q_rc(3));...
             2*(q_rc(2)*q_rc(3)+q_rc(1)*q_rc(4)), 1-2*q_rc(2)^2-2*q_rc(4)^2, 2*(q_rc(3)*q_rc(4)-q_rc(1)*q_rc(2));...
             2*(q_rc(2)*q_rc(4)-q_rc(1)*q_rc(3)), 2*(q_rc(3)*q_rc(4)+q_rc(1)*q_rc(2)), 1-2*q_rc(2)^2-2*q_rc(3)^2];
    nrorbit=Q_rc*avn2_0(:,k);       

    j1=atan2(sin(j)*Ra1,cos(j)*Rb1);
    j2=atan2(sin(j)*Ra2,cos(j)*Rb2);
 
    Rj1=sqrt(Ra1*Ra1*cos(j1)*cos(j1) + Rb1*Rb1*sin(j1)*sin(j1));
    Rj2=sqrt(Ra2*Ra2*cos(j2)*cos(j2) + Rb2*Rb2*sin(j2)*sin(j2));

    lorbit(:,m)=ar0n(:,k)+ar01(:,k)/b1+Rj1/b2*nlorbit;
    rorbit(:,m)=ar0n(:,k)+ar02(:,k)/b1+Rj2/b2*nrorbit;

end

plot3(lorbit(1,1:105),lorbit(2,1:105),lorbit(3,1:105),'color',[0 0 0],'linewidth',3);
plot3(rorbit(1,1:105),rorbit(2,1:105),rorbit(3,1:105),'color',[0 0 0],'linewidth',3);

px_rot=pn(1,frameno);
py_rot=pn(2,frameno);
pz_rot=pn(3,frameno);
bodyrot=[0;-pz_rot;py_rot];
bodyrot=bodyrot/sqrt(sum(bodyrot.^2));
bodyangle=acos(sum(pn(1,frameno).*ez_l));

if (px_rot==1) 
    bodyrot=[1 0 0];
    bodyangle=0;
end

ex_rot=-en(1,frameno);
ey_rot=-en(2,frameno);
ez_rot=-en(3,frameno);
eyerot=[ex_rot;-ey_rot;0];
eyerot=eyerot/sqrt(sum(eyerot.^2));
eyeangle=acos(sum(-en(1,frameno).*(-ey_b)));

Euglenaplot(xc,yc,zc,bodylength,thickness,bodyrot,bodyangle,eyerot,eyeangle,0.6,1/0.6)     

xlc=ar1np(1,frameno);
ylc=ar1np(2,frameno);
zlc=ar1np(3,frameno);

xrc=ar2np(1,frameno);
yrc=ar2np(2,frameno);
zrc=ar2np(3,frameno);

[xl1, yl1, zl1] = ellipsoid(xlc,ylc,zlc,thickness*0.08,thickness*0.08,thickness*0.08,10);
E1 = surfl(xl1, yl1, zl1);
set(E1,'FaceColor',[0 0.2 1],'FaceAlpha',1,'EdgeColor','none'); 

[xr2, yr2, zr2] = ellipsoid(xrc,yrc,zrc,thickness*0.08,thickness*0.08,thickness*0.08,10);
E2 = surfl(xr2, yr2, zr2);
set(E2,'FaceColor',[1 0 0],'FaceAlpha',1,'EdgeColor','none'); 

[x0, y0, z0] = ellipsoid(xc+pn(1,frameno)*bodylength*0+en(1,frameno)*thickness*0.5,yc+pn(2,frameno)*bodylength*0+en(2,frameno)*thickness*0.5,zc+pn(3,frameno)*bodylength*0+en(3,frameno)*thickness*0.5,thickness*0.15,thickness*0.15,thickness*0.15,10);
E0 = surfl(x0, y0, z0);
set(E0,'FaceColor',[1 129/255 25/255],'FaceAlpha',1,'EdgeColor','none'); 
axis equal;
set(gca,'FontSize',16);
set(gca,'linewidth',1);
axis equal
xlim([-15 15]);
ylim([-70 10]);
zlim([-40 40]);
xticks(-15:7.5:0)
yticks(-70:20:10)
zticks(-40:20:40)
xtickangle(0)
ytickangle(0)
ztickangle(0)
view([-90 0]);
xlabel('x','FontSize',16);
ylabel('y','FontSize',16);
zlabel('z','FontSize',16);
%set(gcf,'Position',[50 50 500 200])
drawnow;
set(gca,'linewidth',1)
set(gca,'FontWeight','normal')
set(gca,'FontSize',21)
set(gca,'XColor',[0,0,0])
set(gca,'YColor',[0,0,0])
set(gca,'ZColor',[0,0,0])

drawnow;


fig2 = copyobj(fig1, 0);
view([0 0]);
xlim([-10 10]);
xticks(-10:10:10)
